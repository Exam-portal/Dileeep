package com.dileep.onlineexam.dao;

import java.util.List;

import com.dileep.onlineexam.model.UserHistory;

public interface UserHistoryDao {

	public List<UserHistory> findAllUserHistory(int userId);
	public void addUserHistory(UserHistory userHistory);
	public UserHistory findUser(int id);
	public boolean updateUser(UserHistory userHistory);
	public boolean deleteUser(UserHistory userHistory);
}
