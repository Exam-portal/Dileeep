package com.dileep.onlineexam.controller;

public class DeleteUserHistoryException extends RuntimeException{
	public DeleteUserHistoryException() {
		super();
	}

	@Override
	public String toString() {
		return "Unable to delete user history";
	}
}
