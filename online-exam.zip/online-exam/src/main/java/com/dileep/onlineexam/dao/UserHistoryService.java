package com.dileep.onlineexam.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dileep.onlineexam.model.UserHistory;

@Service
public class UserHistoryService {

	@Autowired
	UserHistoryDaoImpl userHistoryDaoImpl;
	
	public List<UserHistory> findAllUserHistory(int userId){
		return userHistoryDaoImpl.findAllUserHistory(userId);
	}
	
	public void addUserHistory(UserHistory userHistory) {
		userHistoryDaoImpl.addUserHistory(userHistory);
	}
}
