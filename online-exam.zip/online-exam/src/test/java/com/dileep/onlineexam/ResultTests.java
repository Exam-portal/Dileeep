package com.dileep.onlineexam;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dileep.onlineexam.dao.ResultService;
import com.dileep.onlineexam.model.Result;

@SpringBootTest
public class ResultTests {

	@Autowired
	ResultService resultService;
	
	@Test
	void testGetAllResult() {
		Result result = new Result();
		result.setUserId(1);
		result.setTestId(1);
		result.setQuestionId(2);
		result.setExamDate(new Date());
		result.setExamScore(25);
		resultService.add(result);
		assertNotNull(resultService.getAllResult(1));
	}
}
