package com.dileep.onlineexam;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.dileep.onlineexam.dao.UserHistoryService;
import com.dileep.onlineexam.model.UserHistory;

@SpringBootTest
public class UserHistoryTests {

	@Autowired
	UserHistoryService userHistoryService;
	
	@Test
	void findAllUserHistory() {
		UserHistory userHistory = new UserHistory();
		userHistory.setTestId(1);
		userHistory.setTestDate(new Date());
		userHistory.setTestScore(20);
		userHistory.setUserId(1);
		userHistoryService.addUserHistory(userHistory);
		assertNotNull(userHistoryService.findAllUserHistory(1));
	}
}
