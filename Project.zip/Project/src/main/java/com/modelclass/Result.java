package com.modelclass;

public class Result {
     private int Userid;
     private int Testid;
     private int Questionid;
     private String ExamDate;
     private int ExamScore;
     
     
     public Result()
     {
    	 
     }


	public int getUserid() {
		return Userid;
	}


	public void setUserid(int userid) {
		Userid = userid;
	}


	public int getTestid() {
		return Testid;
	}


	public void setTestid(int testid) {
		Testid = testid;
	}


	public int getQuestionid() {
		return Questionid;
	}


	public void setQuestionid(int questionid) {
		Questionid = questionid;
	}


	public String getExamDate() {
		return ExamDate;
	}


	public void setExamDate(String examDate) {
		ExamDate = examDate;
	}


	public int getExamScore() {
		return ExamScore;
	}


	public void setExamScore(int examScore) {
		ExamScore = examScore;
	}
     
}
