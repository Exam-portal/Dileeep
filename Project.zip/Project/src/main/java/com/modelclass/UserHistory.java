package com.modelclass;

public class UserHistory {

}
