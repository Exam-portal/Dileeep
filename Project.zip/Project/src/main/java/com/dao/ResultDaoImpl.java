package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.modelclass.Result;
@Component
public class ResultDaoImpl implements ResultDao {
@Autowired

SessionFactory sessionFactory;
	@Override
	public void addResult(Result result) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(result);
		session.flush();
		session.getTransaction().commit();
		session.close();
		
	}

	@Override
	public Result findResult(int id) {
		Session session=sessionFactory.openSession();
	    Result result=session.find(Result.class, id);
		// TODO Auto-generated method stub
		return result;
	}

	@Override
	public List<Result> findAllResult() {
		Session session=sessionFactory.openSession();
		List<Result> resultlist=session.createQuery("select r from Result r").list();
				
		// TODO Auto-generated method stub
		return resultlist;

	}

	@Override
	public boolean updateResult(Result result) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(result);
		session.flush();
		session.getTransaction().commit();
		session.close();
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean deleteResult(Result result) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(result);
		session.flush();
		session.getTransaction().commit();
		session.close();
		// TODO Auto-generated method stub
		return false;
	}

}
