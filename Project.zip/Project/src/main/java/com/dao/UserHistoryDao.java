package com.dao;

import java.util.List;

import com.modelclass.UserHistory;

public interface UserHistoryDao {
	public void addUserHistory(UserHistory history);
	public UserHistory findUserHistory(int id);
	public List<UserHistory> findAllUserHistory();
	public boolean updateUserHistory(UserHistory history);
	public boolean deleteUserHistory(UserHistory history);
}
