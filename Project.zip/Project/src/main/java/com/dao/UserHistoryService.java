package com.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.modelclass.Result;
import com.modelclass.UserHistory;

public class UserHistoryService {
	
	
	@Autowired
	UserHistoryDao UserHistoryDAOImpl;
	
	public void add(UserHistory history)
	{
		UserHistoryDAOImpl.addUserHistory(history);
	}
	public UserHistory find(int id)
	{
		return UserHistoryDAOImpl.findUserHistory(id);
	}
	public List <UserHistory> findAll()
	{
		return UserHistoryDAOImpl.findAllUserHistory();
	}
	public boolean update(UserHistory history)
	{
		return UserHistoryDAOImpl.updateUserHistory(history);
	}
	public boolean delete(UserHistory history)
	{
		return UserHistoryDAOImpl.deleteUserHistory(history);
	}

}



