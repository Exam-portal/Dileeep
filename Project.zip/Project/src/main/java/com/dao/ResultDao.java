package com.dao;

import java.util.*;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;

import com.modelclass.Result;


public interface ResultDao {
	public void addResult(Result result);
	public Result findResult(int id);
	public List<Result> findAllResult();
	public boolean updateResult(Result result);
	public boolean deleteResult(Result result);

}
