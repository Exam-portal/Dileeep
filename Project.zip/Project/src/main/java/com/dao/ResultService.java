package com.dao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.modelclass.Result;
import java.util.List;
@Service
public class ResultService {
@Autowired
	ResultDao ResultDAOImpl;
	
	public void add(Result result)
	{
		ResultDAOImpl.addResult(result);
	}
	public Result find(int id)
	{
		return ResultDAOImpl.findResult(id);
	}
	public List <Result> findAll()
	{
		return ResultDAOImpl.findAllResult();
	}
	public boolean update(Result result)
	{
		return ResultDAOImpl.updateResult(result);
	}
	public boolean delete(Result result)
	{
		return ResultDAOImpl.deleteResult(result);
	}

}


