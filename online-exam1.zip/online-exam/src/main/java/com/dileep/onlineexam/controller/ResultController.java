package com.dileep.onlineexam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dileep.onlineexam.dao.ResultService;
import com.dileep.onlineexam.model.Result;

@RestController
public class ResultController {

	@Autowired
	ResultService resultService;
	
	@GetMapping("/getResults/{userId}")
	public List<Result> getAllResults(@PathVariable(value="userId") int userId) {
		return resultService.getAllResult(userId);
	}
	
	@PostMapping("/addResult")
	public String addResult(@RequestBody Result result) {
		resultService.add(result);
		return "result added successfully";
	}
}
