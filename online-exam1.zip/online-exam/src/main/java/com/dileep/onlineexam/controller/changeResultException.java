package com.dileep.onlineexam.controller;

public class changeResultException extends RuntimeException {
 public changeResultException()  {
	 super("Result cannot be changed successfully");
	 
 }
 public String toString() {
	 return "Result cannot be changed kindly remove one password";
 }
}
