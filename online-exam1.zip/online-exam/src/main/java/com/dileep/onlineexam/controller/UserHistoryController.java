package com.dileep.onlineexam.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.dileep.onlineexam.dao.UserHistoryService;
import com.dileep.onlineexam.model.UserHistory;

@RestController
public class UserHistoryController {

	@Autowired
	UserHistoryService userHistoryService;
	
	@GetMapping("/getUserHistory/{userId}")
	public List<UserHistory> getAllResults(@PathVariable(value="userId") int userId) {
		return userHistoryService.findAllUserHistory(userId);
	}
	
	@PostMapping("/addUserHistory")
	public String addResult(@RequestBody UserHistory userHistory) {
		userHistoryService.addUserHistory(userHistory);
		return "result added successfully";
	}
}
