package com.dileep.onlineexam.controller;



public class changeUserHistoryException extends RuntimeException {
	public changeUserHistoryException()  {
		 super("UserHistory cannot be changed successfully");
		 
	 }

	public String toString() {
		return "UserHistory cannot be changed kindly remove one password";
	}
}
