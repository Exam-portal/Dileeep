package com.dileep.onlineexam.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.bind.annotation.ControllerAdvice;
@ControllerAdvice
public class changeResultExceptionController {
	@ExceptionHandler()
public ResponseEntity<?> handleChangeResultException(changeResultException c,WebRequest req){
	return new ResponseEntity<>(c.toString(),HttpStatus.NOT_FOUND);
}
}
