package com.dileep.onlineexam.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dileep.onlineexam.model.Result;

@Component
public class ResultDaoImpl implements ResultDao{

	@Autowired
	SessionFactory sessionFactory;

	@Override
	public List<Result> findAllResult(int userId) {
		Session session=sessionFactory.openSession();
//		List<Result> resultList = session.createQuery("select r from Result r").list();
//		List<Result> resultList = session.(Result.class, userId);
		Query query = session.createQuery("select r from Result r where r.userId = :userId");
	    query.setInteger("userId", userId);
	    List<Result> resultList = query.getResultList();
		return resultList;
	}

	@Override
	public void addResult(Result result) {
		Session session=sessionFactory.openSession();
		session.getTransaction().begin();
		session.save(result);
		session.flush();
		session.getTransaction().commit();
		session.close();		
	}
	
	
}
